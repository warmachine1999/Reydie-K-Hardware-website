<!DOCTYPE html>
<html lang="en">
<head>
<title>Page Title</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

/* Style the body */
body {
  font-family: Arial, Helvetica, sans-serif;
 
}

/* Header/logo Title */
.header {
  padding: 80px;
  text-align: center;
  background: #1abc9c;
  color: white;
}

/* Increase the font size of the heading */
.header h1 {
  font-size: 40px;
}

/* Sticky navbar - toggles between relative and fixed, depending on the scroll position. It is positioned relative until a given offset position is met in the viewport - then it "sticks" in place (like position:fixed). The sticky value is not supported in IE or Edge 15 and earlier versions. However, for these versions the navbar will inherit default position */
.navbar {
  overflow: hidden;
  background-color: #333;
  position: sticky;
  position: -webkit-sticky;
  top: 0;
}

/* Style the navigation bar links */
.navbar a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 20px;
  text-decoration: none;
}


/* Right-aligned link */
.navbar a.right {
  float: right;
}

/* Change color on hover */
.navbar a:hover {
  background-color: #ddd;
  color: black;
}

/* Active/current link */
.navbar a.active {
  background-color: #666;
  color: white;
}

/* Column container */
.row {  
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
}

/* Create two unequal columns that sits next to each other */
/* Sidebar/left column */
.side {
  -ms-flex: 30%; /* IE10 */
  flex: 30%;
  background-color: #f1f1f1;
  padding: 20px;
}

/* Main column */
.main {   
  -ms-flex: 70%; /* IE10 */
  flex: 70%;
  background-color: white;
  padding: 40px;
}

/* Fake image, just for this example */
.fakeimg {
  background-color: #aaa;
  width: 100%;
  padding: 20px;
}

/* Footer */
.footer {
  padding: 20px;
  text-align: center;
  background: #ddd;
}

/* Responsive layout - when the screen is less than 700px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 700px) {
  .row {   
    flex-direction: column;
  }
}

/* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
@media screen and (max-width: 400px) {
  .navbar a {
    float: none;
    width: 100%;
  }
}

#wrapper{
	width:100%;
	
}

#nav {
	float: right;
	margin-top:30px;
	margin-bottom: 30px;
	margin-right: 23%;
}

ul#navigation {
	margin:0px auto;
	position:relative;
	float:left;
	border-left:1px solid #c4dbe7;
	border-right:1px solid #c4dbe7;
	
}


ul#navigation li {
	display:inline;
	font-size:12px;
	font-weight:bold;
	margin:0;
	padding:0;
	float:left;
	position:relative;
	border-top:1px solid #c4dbe7;
	border-bottom:2px solid #c4dbe7;
}

ul#navigation li a {
	padding:10px 25px;
	color:#616161;
	text-shadow:1px 1px 0px #fff;
	text-decoration:none;
	display:inline-block;
	border-right:1px solid #fff;
	border-left:1px solid #C2C2C2;
	border-top:1px solid #fff;
	background: #f5f5f5;
	
	-webkit-transition:color 0.2s linear, background 0.2s linear;	
	-moz-transition:color 0.2s linear, background 0.2s linear;	
	-o-transition:color 0.2s linear, background 0.2s linear;	
	transition:color 0.2s linear, background 0.2s linear;	
}

ul#navigation li a:hover {
	background:#f8f8f8;
	color:#282828;
}

ul#navigation li:hover > a {
	background:#fff;
}

/* Drop-Down Navigation */
ul#navigation li:hover > ul
{
	visibility:visible;
	opacity:1;
}

ul#navigation ul, ul#navigation ul li ul {
	list-style: none;
    margin: 0;
    padding: 0;    
	visibility:hidden;
    position: absolute;
    z-index: 99999;
	width:180px;
	background:#f8f8f8;
	box-shadow:1px 1px 3px #ccc;
	opacity:0;
	-webkit-transition:opacity 0.2s linear, visibility 0.2s linear; 
	-moz-transition:opacity 0.2s linear, visibility 0.2s linear; 
	-o-transition:opacity 0.2s linear, visibility 0.2s linear; 
	transition:opacity 0.2s linear, visibility 0.2s linear; 	
}

ul#navigation ul {
    top: 43px;
    left: 1px;
}

ul#navigation ul li ul {
    top: 0;
    left: 181px;
}

ul#navigation ul li {
	clear:both;
	width:100%;
	border:0 none;
	border-bottom:1px solid #c9c9c9;
}

ul#navigation ul li a {
	background:none;
	padding:7px 15px;
	color:#616161;
	text-shadow:1px 1px 0px #fff;
	text-decoration:none;
	display:inline-block;
	border:0 none;
	float:left;
	clear:both;
	width:150px;
}

ul#navigation li a.first {
	border-left: 0 none;
}

ul#navigation li a.last {
	border-right: 0 none;
}

body {
	margin:0;
	padding:0;
	font:12px/20px Arial;
}
#navbar {
  overflow: hidden;
  background-color: #eee;
  padding: 20px 5px;
  height:100px;
  position: fixed;
  width:100%;
  z-index: 1;
}
#navbar a {
margin: 5px;
  margin-top: -1%;
  float: left;
  color: black;
  text-align: center;
  padding: 10px;
  text-decoration: none;
  font-size: 18px;
  line-height: 20px;
  border-radius: 4px;
}

#navbar a:hover {
  background-color: #ddd;
  color: black;
}
#navbar a.active {
  background-color: dodgerblue;
  color: white;
}
#navbar-right {
  float: right;
  margin-top: 1%;
  margin-right: 30px;
}
.avatar {
  vertical-align: middle;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  margin-left: 20px;
}



.footer-distributed{
	background-color: #292c2f;
	box-shadow: 0 1px 1px 0 rgba(0, 0, 0, 0.12);
	box-sizing: border-box;
	width: 100%;
	text-align: left;
	font: bold 16px sans-serif;

	padding: 55px 50px;
	margin-top: 80%;
}

.footer-distributed .footer-left,
.footer-distributed .footer-center,
.footer-distributed .footer-right{
	display: inline-block;
	vertical-align: top;
}

/* Footer left */

.footer-distributed .footer-left{
	width: 40%;
}

/* The company logo */



.footer-distributed h3 span{
	color:  #5383d3;
}

/* Footer links */

.footer-distributed .footer-links{
	color:  #ffffff;
	margin: 20px 0 12px;
	padding: 0;
}

.footer-distributed .footer-links a{
	display:inline-block;
	line-height: 1.8;
	text-decoration: none;
	color:  inherit;
}

.footer-distributed .footer-company-name{
	color:  #8f9296;
	font-size: 14px;
	margin-top: 10%;
	font-weight: normal;
	margin-left: 20%;
}

/* Footer Center */

.footer-distributed .footer-center{
	width: 35%;
}

.footer-distributed .footer-center i{
	background-color:  #33383b;
	color: #ffffff;
	font-size: 25px;
	width: 38px;
	height: 38px;
	border-radius: 50%;
	text-align: center;
	line-height: 42px;
	margin: 10px 15px;
	vertical-align: middle;
}

.footer-distributed .footer-center i.fa-envelope{
	font-size: 17px;
	line-height: 38px;
}

.footer-distributed .footer-center p{
	display: inline-block;
	color: #ffffff;
	vertical-align: middle;
	margin:0;
}

.footer-distributed .footer-center p span{
	display:block;
	font-weight: normal;
	font-size:14px;
	line-height:2;
}

.footer-distributed .footer-center p a{
	color:  #5383d3;
	text-decoration: none;;
}


/* Footer Right */

.footer-distributed .footer-right{
	width: 20%;
}

.footer-distributed .footer-company-about{
	line-height: 20px;
	color:  #92999f;
	font-size: 13px;
	font-weight: normal;
	margin: 0;
}

.footer-distributed .footer-company-about span{
	display: block;
	color:  #ffffff;
	font-size: 14px;
	font-weight: bold;
	margin-bottom: 20px;
}

.footer-distributed .footer-icons{
	margin-top: 25px;
}

.footer-distributed .footer-icons a{
	display: inline-block;
	width: 35px;
	height: 35px;
	cursor: pointer;
	background-color:  #33383b;
	border-radius: 2px;

	font-size: 20px;
	color: #ffffff;
	text-align: center;
	line-height: 35px;

	margin-right: 3px;
	margin-bottom: 5px;
}

/* If you don't want the footer to be responsive, remove these media queries */

@media (max-width: 880px) {

	.footer-distributed{
		font: bold 14px sans-serif;
	}

	.footer-distributed .footer-left,
	.footer-distributed .footer-center,
	.footer-distributed .footer-right{
		display: block;
		width: 100%;
		margin-bottom: 40px;
		text-align: center;
	}

	.footer-distributed .footer-center i{
		margin-left: 0;
	}

}

.tablink {
  background-color: #555;
  color: white;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  font-size: 17px;
  width: 25%;
}

/* Change background color of buttons on hover */
.tablink:hover {
  background-color: #777;
}

/* Set default styles for tab content */
.tabcontent {
  color: white;
  display: none;
  padding: 50px;
  text-align: center;
}

.slideshow-container {
  max-width: 1000px;
  position: relative;
  
  
}
.mySlides {
  display: none;
}
.text {
  color: white;
  font-size: 35px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  text-align: left;
}
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.9s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}


.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  padding: 50px;
  float: left;
  margin: 5px;
  margin-right: 10px;
  text-align: center;
  margin-top: 5%;
  font-family: arial;
}

.price {
  color: grey;
  font-size: 22px;
}

.btn{
  border: none;
  outline: 0;
  margin-top: 15px;
  padding: 12px;
  color: white;
  background-color: Green;
  text-align: center;
  cursor: pointer;
  width: 90%;
  font-size: 18px;
}

.card button:hover {
  opacity: 0.7;
}

h2{
            text-align: center;
            color: #66afe9;
            background-color: #efefef;
            padding: 2%;
        }
	
</style>
</head>
<body>
<div id= navbar >
  <img style="height: 40%px;width:15%;margin-left:30px;" src=logo.png >
  <div id= navbar-right >
   <a href= index.php class="fa fa-home" style="font-size:30px"></a>
    <a href= Shop.php class= active>Shop</a>
	<a href= Cart.php>Cart</a>
    <a href= Contact.php abbr title="Contact" class="fa fa-address-book" style="font-size:22px" aria-hidden="true"></a>
   <a href= About.php abbr title="About" class="fa fa-question-circle" style="font-size:25px" aria-hidden="true"></a>
 
  </div>
</div>
<br>
<br>
<br>
  <br>
  <br>
  <br>

 
<form>
<?php
$i1 = "Hammer";
$i2 = "Hammer";
$i3 = "Hammer";
$i4 = "Hammer";
$i5 = "Hammer";
$i6 = "Hammer";
$i7 = "Hammer";
$i8 = "Hammer";


$Pprice1 = "300";
$Pprice2 = "300";
$Pprice3 = "300";
$Pprice4 = "300";
$Pprice5 = "300";
$Pprice6 = "300";
$Pprice7 = "300";
$Pprice8 = "300";


?>

<h2>Shopping Cart</h2>
  <div class="main">
   <div id= wrapper >
<nav id= nav >
	<ul id= navigation >
		<li><a href= Shop.php class= active >Home</a></li>
		<li><a href= category2.php >Cutting Tools</a>
		<li><a href= category3.php >Electrical Tools</a>			
		<li><a href= category4.php >Measuring Tools</a></li>
		<li><a href= category5.php >Painting Tools</a></li>
		<li><a href= others.php  class= last >Others</a></li>
	</ul>
</nav>
</div>
 <form action="Shop.php" method="POST">
<div class="card">
  <img src="o2.png" alt="Denim Jeans" style="width:100%">
  <h1><?php echo $i1; ?></h1>
  <p class="price"><?php echo $Pprice1; ?></p>
   <input type="text" style="text-align:center;width:40%;" name="q1" class="form-control" value="1">
  <input class="btn" type="submit" name="insert" value="Add to Cart">
</div>
<div class="card">
  <img src="o3.png" alt="Denim Jeans" style="width:100%">
  <h1><?php echo $i1; ?></h1>
  <p class="price"><?php echo $Pprice1; ?></p>
  <input type="text" style="text-align:center;width:40%;" name="q2" class="form-control" value="1">
  <input class="btn" type="submit" name="insert" value="Add to Cart">
</div>

<div class="card">
  <img src="o4.png" alt="Denim Jeans" style="width:100%">
  <h1><?php echo $i1; ?></h1>
  <p class="price"><?php echo $Pprice1; ?></p>
  <input type="text" style="text-align:center;width:40%;" name="q3" class="form-control" value="1">
  <input class="btn" type="submit" name="insert" value="Add to Cart">
</div>
<div class="card">
  <img src="o5.png" alt="Denim Jeans" style="width:100%">
  <h1><?php echo $i1; ?></h1>
  <p class="price"><?php echo $Pprice1; ?></p>
 <input type="text" style="text-align:center;width:40%;" name="q4" class="form-control" value="1">
  <input class="btn" type="submit" name="insert" value="Add to Cart">
</div>
<div class="card">
  <img src="o6.png" alt="Denim Jeans" style="width:100%">
  <h1><?php echo $i1; ?></h1>
  <p class="price"><?php echo $Pprice1; ?></p>
  <input type="text" style="text-align:center;width:40%;" name="q5" class="form-control" value="1">
  <input class="btn" type="submit" name="insert" value="Add to Cart">
</div>
<div class="card">
  <img src="o7.png" alt="Denim Jeans" style="width:100%">
  <h1><?php echo $i1; ?></h1>
  <p class="price"><?php echo $Pprice1; ?></p>
  <input type="text" style="text-align:center;width:40%;" name="q6" class="form-control" value="1">
  <input class="btn" type="submit" name="insert" value="Add to Cart">
</div>
<div class="card">
  <img src="o8.png" alt="Denim Jeans" style="width:100%">
  <h1><?php echo $i1; ?></h1>
  <p class="price"><?php echo $Pprice1; ?></p>
  <input type="text" style="text-align:center;width:40%;" name="q7" class="form-control" value="1">
  <input class="btn" type="submit" name="insert" value="Add to Cart">
</div>
<div class="card">
  <img src="o1.png" alt="Denim Jeans" style="width:100%">
  <h1><?php echo $i1; ?></h1>
  <p class="price"><?php echo $Pprice1; ?></p>
  <input type="text" style="text-align:center;width:40%;" name="q8" class="form-control" value="1">
  <input class="btn" type="submit" name="insert" value="Add to Cart">
</div>
</div>
</form>



		
<footer class= footer-distributed >

			<div class= footer-left >

				<img style="height:15%;width:70%;margin-left:0px;margin-top:5%;" src=logo.png >


				<p class= footer-company-name >Execute &copy; 2019</p>
			</div>

			<div class= footer-right >

				<p class= footer-company-about >
					<span>About Company </span>Reydie K Hardware or Reymond Edie Kabigting Hardware, The company is managed by the family of Kabigting, 
and the President of the hardware which is the father of the family Kabigting, Mr......
</span>
				</p>

				<div class= footer-icons >
				<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
  <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
  <a href="#" class="google"><i class="fa fa-google"></i></a>
  <a href="#" class="youtube"><i class="fa fa-youtube"></i></a>

				</div>

			</div>

			<div STYLE="float: right;" class= footer-right >

			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4436.643852957726!2d121.04018957460768!3d14.777228289785706!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397afd00f8846bf%3A0xb06ac44183dd36a5!2sBagong%20Silang%2C%20Caloocan%2C%20Metro%20Manila!5e1!3m2!1sen!2sph!4v1570320735217!5m2!1sen!2sph" width="600" height="450" frameborder="0" style="border:0;height: 200px;margin-right: 40px;width:110%;" allowfullscreen=""></iframe>
				

			</div>

		</footer>
            
</body>
</html>
