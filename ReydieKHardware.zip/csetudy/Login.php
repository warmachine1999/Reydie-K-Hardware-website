  <style>
  @import "bourbon";

body {
	background: #eee !important;	
}

.wrapper {	
	margin-top: 80px;
  margin-bottom: 80px;
}

.form-signin {
  max-width: 380px;
  padding: 15px 35px 45px;
  margin: 0 auto;
  background-color: #f1f1;
  border: 1px solid rgba(0,0,0,0.1);  

  .form-signin-heading,
	.checkbox {
	  margin-bottom: 30px;
	}

	.checkbox {
	  font-weight: normal;
	}

	.form-control {
	  position: relative;
	  font-size: 10px;
	  height: auto;
	  padding: 10px;
		@include box-sizing(border-box);

		&:focus {
		  z-index: 2;
		}
	}

	input[type="text"] {
	  margin-bottom: -1px;
	  border-bottom-left-radius: 0;
	  border-bottom-right-radius: 0;
	  padding: 5px;
	}

	input[type="password"] {
	  margin-bottom: 20px;
	  border-top-left-radius: 0;
	  border-top-right-radius: 0;
	}
}

  </style>
  <div class="wrapper">
  <link rel="stylesheet" type="text/css" href="baypart2.css"> 
    <form class="form-signin"> 
		<CENTER>
      <h2 class="form-signin-heading">MEMBER LOGIN</h2>
	  <img src ="user1.jpeg" height="16px" width="16px"> 
      <input type="text" class="form-control" name="username" placeholder="Username" required="" autofocus="" />
	  <br>
	  <img src="lock.png" height="16px" width="16px"> 
	  <input type="password" class="form-control" name="password" placeholder="Password" required=""/>
      </br>
	  <button class="btn btn-lg btn-primary btn-block" type="submit"><a href="shop2.php">Sign in</button>   </a>
    </form>
  </div></center>