
<style>

	body {
	margin:0;
	padding:0;
	font:12px/20px Arial;
}
#navbar {
  overflow: hidden;
  background-color: #eee;
  padding: 20px 5px;
  height:100px;
  position: fixed;
  width:100%;
  z-index: 1;
}
#navbar a {
margin: 5px;
  margin-top: -1%;
  float: left;
  color: black;
  text-align: center;
  padding: 10px;
  text-decoration: none;
  font-size: 18px;
  line-height: 20px;
  border-radius: 4px;
}

#navbar a:hover {
  background-color: #ddd;
  color: black;
}
#navbar a.active {
  background-color: dodgerblue;
  color: white;
}
#navbar-right {
  float: right;
  margin-top: 1%;
  margin-right: 30px;
}
.avatar {
  vertical-align: middle;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  margin-left: 20px;
}





.tablink {
  background-color: #555;
  color: white;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  font-size: 17px;
  width: 25%;
}

/* Change background color of buttons on hover */
.tablink:hover {
  background-color: #777;
}

/* Set default styles for tab content */
.tabcontent {
  color: white;
  display: none;
  padding: 50px;
  text-align: center;
}

.body {
  background-color:#001a33;
  padding: 20px;
  margin-top: 2px;
  height: 200%;
}



.footer-distributed{
	background-color: #292c2f;
	box-shadow: 0 1px 1px 0 rgba(0, 0, 0, 0.12);
	box-sizing: border-box;
	width: 100%;
	text-align: left;
	font: bold 16px sans-serif;

	padding: 55px 50px;
	margin-top: 0px;
}

.footer-distributed .footer-left,
.footer-distributed .footer-center,
.footer-distributed .footer-right{
	display: inline-block;
	vertical-align: top;
}

/* Footer left */

.footer-distributed .footer-left{
	width: 40%;
}

/* The company logo */



.footer-distributed h3 span{
	color:  #5383d3;
}

/* Footer links */

.footer-distributed .footer-links{
	color:  #ffffff;
	margin: 20px 0 12px;
	padding: 0;
}

.footer-distributed .footer-links a{
	display:inline-block;
	line-height: 1.8;
	text-decoration: none;
	color:  inherit;
}

.footer-distributed .footer-company-name{
	color:  #8f9296;
	font-size: 14px;
	margin-top: 10%;
	font-weight: normal;
	margin-left: 20%;
}

/* Footer Center */

.footer-distributed .footer-center{
	width: 35%;
}

.footer-distributed .footer-center i{
	background-color:  #33383b;
	color: #ffffff;
	font-size: 25px;
	width: 38px;
	height: 38px;
	border-radius: 50%;
	text-align: center;
	line-height: 42px;
	margin: 10px 15px;
	vertical-align: middle;
}

.footer-distributed .footer-center i.fa-envelope{
	font-size: 17px;
	line-height: 38px;
}

.footer-distributed .footer-center p{
	display: inline-block;
	color: #ffffff;
	vertical-align: middle;
	margin:0;
}

.footer-distributed .footer-center p span{
	display:block;
	font-weight: normal;
	font-size:14px;
	line-height:2;
}

.footer-distributed .footer-center p a{
	color:  #5383d3;
	text-decoration: none;;
}


/* Footer Right */

.footer-distributed .footer-right{
	width: 20%;
}

.footer-distributed .footer-company-about{
	line-height: 20px;
	color:  #92999f;
	font-size: 13px;
	font-weight: normal;
	margin: 0;
}

.footer-distributed .footer-company-about span{
	display: block;
	color:  #ffffff;
	font-size: 14px;
	font-weight: bold;
	margin-bottom: 20px;
}

.footer-distributed .footer-icons{
	margin-top: 25px;
}

.footer-distributed .footer-icons a{
	display: inline-block;
	width: 35px;
	height: 35px;
	cursor: pointer;
	background-color:  #33383b;
	border-radius: 2px;

	font-size: 20px;
	color: #ffffff;
	text-align: center;
	line-height: 35px;

	margin-right: 3px;
	margin-bottom: 5px;
}

/* If you don't want the footer to be responsive, remove these media queries */

@media (max-width: 880px) {

	.footer-distributed{
		font: bold 14px sans-serif;
	}

	.footer-distributed .footer-left,
	.footer-distributed .footer-center,
	.footer-distributed .footer-right{
		display: block;
		width: 100%;
		margin-bottom: 40px;
		text-align: center;
	}

	.footer-distributed .footer-center i{
		margin-left: 0;
	}

}
.body{
	top: 30%;
	left: 50%;
}
.box{
	transform: translate(50%,50%);
	margin-top: -10%;
	margin-right: 85%;
	
}
.box  a{
	text-decoration: none;
	font-size: 20px;
	padding: 5px;
	color:white;
}
	
	#font h2{
	font-size: 30px;
	color: black;
	
	}
	
	* {
  box-sizing: border-box;
}

/* Style inputs */
input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

/* Style the container/contact section */
.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 40px;
}

/* Create two columns that float next to eachother */
.column {
  float: left;
  width: 50%;
  margin-top: 6px;
  padding: 20px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
</style>

<div id= navbar >
  <img style="height: 40%px;width:15%;margin-left:30px;" src=logo.png >
  <div id= navbar-right >
    <a href= index.php class="fa fa-home" style="font-size:30px" abbr title="Home"></a>
	<a href= Shop.php class="fa fa-shopping-cart" style="font-size:25px" abbr title="Shop"></i></a>
   <a href= Contact.php abbr title="Contact" class="fa fa-address-book" style="font-size:22px" aria-hidden="true"></a>
<a href= About.php abbr title="About" class="fa fa-question-circle" style="font-size:25px" aria-hidden="true"></a>
  </div>
 
</div>

<br>
<br>
<br>
<br>
	<div class="container">
  <div style="text-align:center">
    <h2>Contact Us</h2>
  </div>
  <div class="row">
    <div class="column">
     			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4436.643852957726!2d121.04018957460768!3d14.777228289785706!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397afd00f8846bf%3A0xb06ac44183dd36a5!2sBagong%20Silang%2C%20Caloocan%2C%20Metro%20Manila!5e1!3m2!1sen!2sph!4v1570320735217!5m2!1sen!2sph" width="600" height="450" frameborder="0" style="border:0;height: 420px;margin-right: 40px;width:100%;" allowfullscreen=""></iframe>

    </div>
	       <script>
function validate() {
    alert(" Form Successfuly Send ! ");
 return true;
}
 
</script>
    <div class="column">
      <form action="Contact2.php" method="Post" onsubmit="return validate()">
        <label for="fname" >First Name</label>
        <input type="text" id="fname" name="fname1" placeholder="Your name..">
        <label for="lname" >Last Name</label>
        <input type="text" id="lname" name="lname2" placeholder="Your last name..">
       
        <label for="subject">Subject</label>
        <textarea id="subject" name="subject" placeholder="Write something.." style="height:170px"></textarea>
        <input type="submit" value="SEND FORM">
      </form>
    </div>
  </div>
</div>









<div class=box1>

	
</div>
<body>
			
		
<footer class= footer-distributed >

			<div class= footer-left >

				<img style="height:15%;width:70%;margin-left:0px;margin-top:5%;" src=logo.png >


				<p class= footer-company-name >Execute &copy; 2019</p>
			</div>

			<div class= footer-right >

				<p class= footer-company-about >
					<span>About  Company </span>Reydie K Hardware or Reymond Edie Kabigting Hardware, The company is managed by the family of Kabigting, 
and the President of the hardware which is the father of the family Kabigting, Mr......
</span>
				</p>

				<div class= footer-icons >
				<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
  <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
  <a href="#" class="google"><i class="fa fa-google"></i></a>
  <a href="#" class="youtube"><i class="fa fa-youtube"></i></a>

				</div>

			</div>

			<div STYLE="float: right;" class= footer-right >

			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4436.643852957726!2d121.04018957460768!3d14.777228289785706!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397afd00f8846bf%3A0xb06ac44183dd36a5!2sBagong%20Silang%2C%20Caloocan%2C%20Metro%20Manila!5e1!3m2!1sen!2sph!4v1570320735217!5m2!1sen!2sph" width="600" height="450" frameborder="0" style="border:0;height: 200px;margin-right: 40px;width:110%;" allowfullscreen=""></iframe>
				

			</div>

		</footer>
            
	</body>

</html> 

