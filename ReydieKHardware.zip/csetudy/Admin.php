

<style>
body {
	background: #eee;
	
}

h2{
            text-align: center;
            color: #66afe9;
            background-color: #efefef;
            padding: 2%;
			font-size: 30px;
        }
	.coll{
		float: right;
		border: 1px;
		background: #eee;
		padding: 30px;
		width: 30%;
		margin: auto;
		margin-top: -34%;
		margin-right: 3%;
	}
	.coll h3{
		font-size: 20px;
		text-align: center;
	}


table, th, tr{
            text-align: center;
        }
        .title2{
            text-align: center;
            color: #66afe9;
			font-size: 30px;
            background-color: #efefef;
            padding: 2%;

        }
        h2{
            text-align: center;
            color: #66afe9;
            background-color: #efefef;
            padding: 2%;
        }
        table {
            background-color: #efefef;
			padding: auto;
        }
		.header p{
			color: gray;
			text-align: center;
			margin-bottom: 30px;
			margin-top: 50px;
			font-size: 20px;
		}
		#header{
			float: leftt;
			margin-left: 0px;
			display: inline-block;
			margin-left: 10px;
		}
		#header a{
			color: blue;
			text-decoration: none;
			font-family: arial;
		}
		#header a:hover{
			color: red;
		}
		h4{
			color: gray;
		}
		#header2{
			float: leftt;
			margin-left: 10px;
			display: inline-block;
		}
		#header2 a{
			color: gray;
			text-decoration: none;
			font-family: arial;
			margin: 30px;
		}
		#header2 a:hover{
			color: black;
		}
		</style>


<?php
include "net.php";


?>		

		<div class="header">
		<p> Welcome to Admin Panel </p>
</div>
		<hr>
		<div id="header">
		<a href="index.php">Logout</a>
		<a href="#"></a>
		<a href="#"> </a>
		<a href="#"> </a>
		</div>
<hr>
	<br>

	<h3 class=title2>Checkout Form Data</h3>
        <div class=table-responsive>
          <table class=table border=1 width=100%;>
            <tr>
                <th width=5%>Firstname</th>
                <th width=10%>Lastname</th>
                <th width=10%>Email</th>
                <th width=10%>Address</th>
                <th width=15%>Barangay</th>
                <th width=15%>City</th>
                <th width=10%>Country</th>
                <th width=10%>PostalCode</th>
                <th width=10%>Phone</th>
				<th width=10%>Remove Data</th>
            </tr>
			<tr>
				<td colspan=10> <hr> </td>
				</tr>
		<?php	
				
		$view_query = mysqli_query($conn, "SELECT * FROM person");	
			while($row = mysqli_fetch_assoc($view_query)){
				
				$user_id = $row["user_id"];
				
				$db_Firstname = $row['Firstname'];
				$db_Lastname = $row['Lastname'];
				$db_Email = $row['Email'];
				$db_Address = $row['Address'];
				$db_Barangay = $row['Barangay'];
				$db_City = $row['City'];
				$db_Country = $row['Country'];
				$db_PostalCode = $row['PostalCode'];
				$db_Phone = $row['Phone'];
				
				$full_name = ucfirst($db_Firstname);
				$last_name = ucfirst($db_Lastname);
				$Em = ucfirst($db_Email);
				$add = ucfirst($db_Address);
				$brgy = ucfirst($db_Barangay);
				$cty = ucfirst($db_City);
				$cntry = ucfirst($db_Country);
				$Postal = ucfirst($db_PostalCode);
				$phone = ucfirst($db_Phone);
				
				echo "
						<tr>
							<td>$full_name</td>
							<td>$last_name</td>
							<td>$Em</td>
							<td>$add</td>
							<td>$brgy</td>
							<td>$cty</td>
							<td>$cntry</td>
							<td>$Postal</td>
							<td>$phone</td>
							<td>
							<center><a href='delete.php?user_id=$user_id' style=text-decoration:none;><font color=red>X</font></a></td></center>
						</tr>		
						</div>
						";
			
			}
			
			

?>	
</table>
<table>

<div class=contact >
	<h3 class=title2>Contact Data</h3>
        <div class=table-responsive>
          <table class=table border=1 width=100%;>
            <tr>
                <th width=5%>Firstname</th>
                <th width=10%>Lastname</th>
                <th width=10%>Email</th>
				<th width=10%>Remove Data</th>
            </tr>
			<tr>
				<td colspan=4> <hr> </td>
				</tr>
		<?php	
				$full_name = " ";
				$last_name = " ";
				$Message = " ";
		
		$view_query = mysqli_query($conn, "SELECT * FROM contact");	
			while($row = mysqli_fetch_array($view_query)){
				
				$user_id = $row["user_id"];
				
				$db_Firstname = $row['Firstname'];
				$db_Lastname = $row['Lastname'];
				$db_Message = $row['Message'];
				
				
				$full_name = ucfirst($db_Firstname);
				$last_name = ucfirst($db_Lastname);
				$Message = ucfirst($db_Message);
				
				
				echo "
						<tr>
							<td>$full_name</td>
							<td>$last_name</td>
							<td>$Message</td>
							<td><center><a href='delete.php?user_id=$user_id' style=text-decoration:none;><font color=red>X</font></a></td></center>
						</tr>
						</div>
						</div>";
			
			}
?>
</table>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<hr>
<br>
<center><div id="header2">

		<a href="index.php">Developers</a>
		<a href="#">About us</a>
		<a href="#">Accounts</a>
		</div>
		<center><h4> Execeute 2019 </h4></center>
		<center>
