<!DOCTYPE html>
<html>
<head>
<title>Case Study</title>
</head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="bootstrap-reboot.min.css">


<body>




</body>
</html>
<style>

	body {
	margin:0;
	padding:0;
	font:12px/20px Arial;

	}
#navbar {
  overflow: hidden;
  background-color: #eee;
  padding: 20px 5px;
  height:100px;
  position: fixed;
  width:100%;
  z-index: 1;
}
#navbar a {

  float: left;
  color: black;
  text-align: center;
  padding: 10px;
  text-decoration: none;
  font-size: 18px;
  line-height: 20px;
  border-radius: 4px;
}

#navbar a:hover {
  background-color: #ddd;
  color: black;
}
#navbar a.active {
  background-color: dodgerblue;
  color: white;
}
#navbar-right {
  float: right;
  margin-top: 1%;
  margin-right: 30px;
}
.avatar {
  vertical-align: middle;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  margin-left: 20px;
}



.tablink {
  background-color: #555;
  color: white;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  font-size: 17px;
  width: 25%;
}

/* Change background color of buttons on hover */
.tablink:hover {
  background-color: #777;
}

/* Set default styles for tab content */
.tabcontent {
  color: white;
  display: none;
  padding: 50px;
  text-align: center;
}


.mySlides {display: none;margin-left:350px;}
img {vertical-align: middle;}
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 2;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}



.footer-distributed{
	background-color: #292c2f;
	box-shadow: 0 1px 1px 0 rgba(0, 0, 0, 0.12);
	box-sizing: border-box;
	width: 100%;
	text-align: left;
	font: bold 16px sans-serif;

	padding: 55px 50px;
	margin-top: 30px;
}

.footer-distributed .footer-left,
.footer-distributed .footer-center,
.footer-distributed .footer-right{
	display: inline-block;
	vertical-align: top;
}

/* Footer left */

.footer-distributed .footer-left{
	width: 40%;
}

/* The company logo */



.footer-distributed h3 span{
	color:  #5383d3;
}

/* Footer links */

.footer-distributed .footer-links{
	color:  #ffffff;
	margin: 20px 0 12px;
	padding: 0;
}

.footer-distributed .footer-links a{
	display:inline-block;
	line-height: 1.8;
	text-decoration: none;
	color:  inherit;
}

.footer-distributed .footer-company-name{
	color:  #8f9296;
	font-size: 14px;
	margin-top: 10%;
	font-weight: normal;
	margin-left: 20%;
}

/* Footer Center */

.footer-distributed .footer-center{
	width: 35%;
}

.footer-distributed .footer-center i{
	background-color:  #33383b;
	color: #ffffff;
	font-size: 25px;
	width: 38px;
	height: 38px;
	border-radius: 50%;
	text-align: center;
	line-height: 42px;
	margin: 10px 15px;
	vertical-align: middle;
}

.footer-distributed .footer-center i.fa-envelope{
	font-size: 17px;
	line-height: 38px;
}

.footer-distributed .footer-center p{
	display: inline-block;
	color: #ffffff;
	vertical-align: middle;
	margin:0;
}

.footer-distributed .footer-center p span{
	display:block;
	font-weight: normal;
	font-size:14px;
	line-height:2;
}

.footer-distributed .footer-center p a{
	color:  #5383d3;
	text-decoration: none;;
}


/* Footer Right */

.footer-distributed .footer-right{
	width: 20%;
}

.footer-distributed .footer-company-about{
	line-height: 20px;
	color:  #92999f;
	font-size: 13px;
	font-weight: normal;
	margin: 0;
}

.footer-distributed .footer-company-about span{
	display: block;
	color:  #ffffff;
	font-size: 14px;
	font-weight: bold;
	margin-bottom: 20px;
}

.footer-distributed .footer-icons{
	margin-top: 25px;
}

.footer-distributed .footer-icons a{
	display: inline-block;
	width: 35px;
	height: 35px;
	cursor: pointer;
	background-color:  #33383b;
	border-radius: 2px;

	font-size: 20px;
	color: #ffffff;
	text-align: center;
	line-height: 35px;

	margin-right: 3px;
	margin-bottom: 5px;
}

/* If you don't want the footer to be responsive, remove these media queries */

@media (max-width: 880px) {

	.footer-distributed{
		font: bold 14px sans-serif;
	}

	.footer-distributed .footer-left,
	.footer-distributed .footer-center,
	.footer-distributed .footer-right{
		display: block;
		width: 100%;
		margin-bottom: 40px;
		text-align: center;
	}

	.footer-distributed .footer-center i{
		margin-left: 0;
	}

}

.container {
  padding: 5%;
  margin-right: 40px;
}

/* Clear floats */
.row:after {
  content: "";
  display: table;
  clear: both
}

/* 2/3 column */
.column-66 {
  float: left;
  width: 100%;
  padding: 300px;
}

/* 1/3 column */
.column-33 {
  float: left;
  width: 100%;
  padding: 20px;
}

/* Add responsiveness - make the columns appear on top of each other instead of next to each other on small screens */
@media screen and (max-width: 1000px) {
  .column-66,
  .column-33 {
    width: 100%;
    text-align: center;
  }
}

.icon-bar {
  position: fixed;
  top: 50%;
  -webkit-transform: translateY(-50%);
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}

/* Style the icon bar links */
.icon-bar a {
  display: block;
  text-align: center;
  padding: 16px;
  transition: all 0.3s ease;
  color: white;
  font-size: 20px;
}

/* Style the social media icons with color, if you want */
.icon-bar a:hover {
  background-color: #000;
}

.facebook {
  background: #3B5998;
  color: white;
}

.twitter {
  background: #55ACEE;
  color: white;
}

.google {
  background: #dd4b39;
  color: white;
}

.linkedin {
  background: #007bb5;
  color: white;
}

.youtube {
  background: #bb0000;
  color: white;
}
</style>

<div id= navbar >
  <img style="height: 40%px;width:15%;margin-left:30px;" src=logo.png >
  <div id= navbar-right >
     <a href= home2.php class= active>Home</a>
    <a href= shop2.php >Shop</a>
    <a href= Contact.php >Contact</a>
    <a href= About.php >About</a>
    <a href= Register.php >Sign Up</a>
    <a href= Shop.php >Log out</a>
	<a href= profile.php >Profile</a>
  </div>
</div>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!-- The social media icon bar -->
<div class="icon-bar">
  <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
  <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
  <a href="#" class="google"><i class="fa fa-google"></i></a>
  <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
  <a href="#" class="youtube"><i class="fa fa-youtube"></i></a>
</div>

<img src="bg1.jpg" style="background-size:cover;background-repeat: no-repeat;width: 100%;height:80%;">
<div class="container">
  <div class="row">
    <div class="column-66">
     sadasd
     sadasd
     sadasd
     sadasd
     <img src="Bg2.jpg" style="background-size:cover;background-repeat: no-repeat;width: 100%;height:80%;">
     sadasd
     sadasd
     sadasd
    </div>
    <div class="column-33">
      asdas.................................
      asdas.................................
      asdas.................................
      asdas.................................
 <img src="Bg3.jpg" style="background-size:cover;background-repeat: no-repeat;width: 100%;height:80%;">
      asdas.................................
      asdas.................................
    </div>
  </div>
</div>

<div class="container">
  <div class="row">
    <div class="column-33">
      ...sd
      ...sd
      ...sd
      ...sd
      ...sd
      ...sd
      ...sd
      ...sd<img src="Bg.png" style="background-size:cover;background-repeat: no-repeat;width: 100%;height:80%;">
      ...sd
      ...sd
      ...sd
      ...sd
      ...sd
    </div>
    <div class="column-66">
      ...asdasd
      ...asdasd
      ...asdasd
      ...asdasd
      ...asdasd<img src="Bg.png" style="background-size:cover;background-repeat: no-repeat;width: 100%;height:80%;">
      ...asdasd
      ...asdasd
      ...asdasd
      ...asdasd
      ...asdasd
      ...asdasd
    </div>
  </div>
</div>


<html>

<head>

	<meta charset= utf-8 >
	<meta http-equiv= X-UA-Compatible  content= IE=edge >
	<meta name= viewport  content= width=device-width, initial-scale=1 >
	<meta name= keywords  content= footer, address, phone, icons  />

	<title>Footer With Address And Phones</title>

	<link rel= stylesheet  href= css/demo.css >
	<link rel= stylesheet  href= css/footer-distributed-with-address-and-phones.css >
	
	<link rel= stylesheet  href= http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css >

	<link href=http://fonts.googleapis.com/css?family=Cookie  rel= stylesheet  type= text/css >

</head>

	<body>

		
		<!-- The content of your page would go here. -->

		<footer class= footer-distributed >

			<div class= footer-left >

				<img style="height:15%;width:70%;margin-left:0px;margin-top:5%;" src=logo.png >


				<p class= footer-company-name >Execute &copy; 2019</p>
			</div>

			<div class= footer-center >

				<div>
					<i class= fa fa-map-marker ></i>
					<p><span>21 Revolution Street</span> Philippines</p>
				</div>

				<div>
					<i class= fa fa-phone ></i>
					<p>+1 555 123456</p>
				</div>

				<div>
					<i class= fa fa-envelope ></i>
					<p><a href= mailto:support@company.com >support@company.com</a></p>
				</div>

			</div>

			<div class= footer-right >

				<p class= footer-company-about >
					<span>About the company</span>
					Lorem ipsum dolor sit amet, consectateur adispicing elit. Fusce euismod convallis velit, eu auctor lacus vehicula sit amet.
				</p>

				<div class= footer-icons >

					<a href= # ><i class= fa fa-facebook ></i></a>
					<a href= # ><i class= fa fa-twitter ></i></a>
					<a href= # ><i class= fa fa-linkedin ></i></a>
					<a href= # ><i class= fa fa-github ></i></a>

				</div>

			</div>

		</footer>

	</body>

</html> 

