<?php
include  "net.php";

	$fname = $_POST['Firstname'];
	$lname = $_POST['Lastname'];
	$email = $_POST['Email'];
	$add = $_POST['Address'];
	$brg = $_POST['Barangay'];
	$city = $_POST['City'];
	$cntry = $_POST['Country'];
	$code = $_POST['PostalCode'];
	$phone = $_POST['Phone'];
	
	$sql = "INSERT INTO person 
	(Firstname,Lastname,Email,Address,Barangay,City,Country,PostalCode,Phone)
	VALUES ('$fname','$lname','$email','$add','$brg','$city','$cntry',$code,$phone)";
	
	if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
header("Location: Checkout1.php");

	?>
