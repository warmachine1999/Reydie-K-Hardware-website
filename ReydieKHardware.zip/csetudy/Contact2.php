<?php
include  "net.php";

	$fname1 = $_POST['fname1'];
	$lname2 = $_POST['lname2'];
	$subj = $_POST['subject'];
	
	$sql = "INSERT INTO contact 
	(Firstname,Lastname,Message)
	VALUES ('$fname1','$lname2','$subj')";
	
	if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
	header("Location: Contact.php");


	?>
