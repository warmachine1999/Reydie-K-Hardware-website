<?php
include  "net.php";


	
	$sql = "SELECT * FROM person 
	";
	
	if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();


	?>
