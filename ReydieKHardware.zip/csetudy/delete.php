<style>
body {
	background: ;
	padding: 50px;
	margin: 50px;
}
.confirm {
	text-align: center;
	border: 1px;
	background: gray;
	width: 20%;
	margin-left: 40%;
	margin-top:10%;
	height: 30%;
}

</style>
<?php
include "net.php";



	$user_id = $_GET['user_id'];

	
	
	$get_record = mysqli_query($conn, "SELECT * FROM person WHERE user_id = '$user_id' ");

	$check_get_record = mysqli_num_rows($get_record);
	
	if($check_get_record > 0 ) {
		//getting
		$row = mysqli_fetch_array($get_record);
		$db_Firstname = $row['Firstname'];
				$db_Lastname = $row['Lastname'];
				$db_Email = $row['Email'];
				$db_Address = $row['Address'];
				$db_Barangay = $row['Barangay'];
				$db_City = $row['City'];
				$db_Country = $row['Country'];
				$db_PostalCode = $row['PostalCode'];
				$db_Phone = $row['Phone'];
				//upperCase  
				$full_name = ucfirst($db_Firstname);
				$last_name = ucfirst($db_Lastname);
				$Em = ucfirst($db_Email);
				$add = ucfirst($db_Address);
				$brgy = ucfirst($db_Barangay);
				$cty = ucfirst($db_City);
				$cntry = ucfirst($db_Country);
				$Postal = ucfirst($db_PostalCode);
				$phone = ucfirst($db_Phone);
				
				
				if(isset($_POST['delete'])){
					mysqli_query($conn, "DELETE FROM person WHERE user_id = '$user_id' ");
					header("location: Admin.php");
				}
			
				?>
				
				<form method="POST">
				<div class=confirm>
					<h1><font color="red"> Are you sure ? </font></h1>
					<br>
					<input style="border:none;padding:12px;background:green;color:white;margin-right:80px;cursor:pointer;" type=submit name="delete" value=delete>
					<a style="text-decoration:none;color:white;" href="Admin.php"><button style="background:green;color:white;border:none;padding:12px;">Cancel</a></button>
				</form
				</div>
				
<?php
	}
	?>
	
	
	
	
	
<?php
include "net.php";



	$user_id = $_GET['user_id'];

	
	
	$get_record = mysqli_query($conn, "SELECT * FROM contact WHERE user_id = '$user_id' ");

	$check_get_record = mysqli_num_rows($get_record);
	
	if($check_get_record > 0 ) {
		//getting
		$row = mysqli_fetch_array($get_record);
				$db_Firstname = $row['Firstname'];
				$db_Lastname = $row['Lastname'];
				$db_Message = $row['Message'];
				
				//upperCase  
				$full_name = ucfirst($db_Firstname);
				$last_name = ucfirst($db_Lastname);
				$Message = ucfirst($db_Message);
				
				
				
				if(isset($_POST['delete'])){
					mysqli_query($conn, "DELETE FROM contact WHERE user_id = '$user_id' ");
					header("location: Admin.php");
				}
			
				?>

				<form >
				<div class=confirm>
					<h1><font color="red"> Are you sure ? </font></h1>
					<br>
					<input type=submit name="delete" value=delete>
					<a href="Admin.php">Cancel</a>
				</form
				</div>
				
<?php
	}
	?>