
<?php
include "net.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Page Title</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="bootstrap-reboot.min.css">
<style>
* {
  box-sizing: border-box;
}

/* Style the body */
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
  
}

/* Header/logo Title */
.header {
  padding: 10px;
  text-align: center;
  background: #;
  color: white;

}

/* Increase the font size of the heading */
.header h1 {
  font-size: 40px;
}

/* Sticky navbar - toggles between relative and fixed, depending on the scroll position. It is positioned relative until a given offset position is met in the viewport - then it "sticks" in place (like position:fixed). The sticky value is not supported in IE or Edge 15 and earlier versions. However, for these versions the navbar will inherit default position */
.navbar {
  overflow: hidden;
  background-color: #333;
  position: sticky;
  position: -webkit-sticky;
  top: 0;
}

/* Style the navigation bar links */
.navbar a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 20px;
  text-decoration: none;
}


/* Right-aligned link */
.navbar a.right {
  float: right;
}

/* Change color on hover */
.navbar a:hover {
  background-color: #ddd;
  color: black;
}

/* Active/current link */
.navbar a.active {
  background-color: #666;
  color: white;
}

/* Column container */
.row {  
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  padding: 30px;
}

/* Create two unequal columns that sits next to each other */
/* Sidebar/left column */
.side {
  -ms-flex: 30%; /* IE10 */
  flex: 30%;
  background-color: #f1f1f1;
  padding: 20px;
}

/* Main column */
.main {   
  -ms-flex: 70%; /* IE10 */
  flex: 70%;
  background-color: white;
  padding: 50px;
}

/* Fake image, just for this example */
.fakeimg {
  background-color: #aaa;
  width: 100%;
  padding: 20px;
}

/* Footer */
.footer {
  padding: 20px;
  text-align: center;
  background: #ddd;
}

/* Responsive layout - when the screen is less than 700px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 700px) {
  .row {   
    flex-direction: column;
  }
}

/* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
@media screen and (max-width: 400px) {
  .navbar a {
    float: none;
    width: 100%;
  }
}
#navbar {
  overflow: hidden;
  background-color: #eee;
  padding: 20px 5px;
  height:100px;
  position: fixed;
  width:100%;
  z-index: 1;
}
#navbar a {

  float: left;
  color: black;
  text-align: center;
  padding: 10px;
  text-decoration: none;
  font-size: 18px;
  line-height: 20px;
  border-radius: 4px;
  margin: 5px;
  margin-top: -1%;
}

#navbar a:hover {
  background-color: #ddd;
  color: black;
}
#navbar a.active {
  background-color: dodgerblue;
  color: white;
}
#navbar-right {
  float: right;
  margin-top: 1%;
  margin-right: 30px;
}
.avatar {
  vertical-align: middle;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  margin-left: 20px;
}



.tablink {
  background-color: #555;
  color: white;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  font-size: 17px;
  width: 25%;
}

/* Change background color of buttons on hover */
.tablink:hover {
  background-color: #777;
}

/* Set default styles for tab content */
.tabcontent {
  color: white;
  display: none;
  padding: 50px;
  text-align: center;
}

.footer-distributed{
	background-color: #434750;
	box-shadow: 0 1px 1px 0 rgba(0, 0, 0, 0.12);
	box-sizing: border-box;
	width: 100%;
	text-align: left;
	font: bold 16px sans-serif;
	padding: 55px 50px;
	margin-top: 30px;
}

.footer-distributed .footer-left,
.footer-distributed .footer-center,
.footer-distributed .footer-right{
	display: inline-block;
	vertical-align: top;
}

/* Footer left */

.footer-distributed .footer-left{
	width: 40%;
}

/* The company logo */



.footer-distributed h3 span{
	color:  #5383d3;
}

/* Footer links */

.footer-distributed .footer-links{
	color:  #ffffff;
	margin: 20px 0 12px;
	padding: 0;
}

.footer-distributed .footer-links a{
	display:inline-block;
	line-height: 1.8;
	text-decoration: none;
	color:  inherit;
}

.footer-distributed .footer-company-name{
	color:  #8f9296;
	font-size: 14px;
	margin-top: 10%;
	font-weight: normal;
	margin-left: 20%;
}

/* Footer Center */

.footer-distributed .footer-center{
	width: 35%;
}

.footer-distributed .footer-center i{
	background-color:  #33383b;
	color: #ffffff;
	font-size: 25px;
	width: 38px;
	height: 38px;
	border-radius: 50%;
	text-align: center;
	line-height: 42px;
	margin: 10px 15px;
	vertical-align: middle;
}

.footer-distributed .footer-center i.fa-envelope{
	font-size: 15px;
	line-height: 38px;
}

.footer-distributed .footer-center p{
	display: inline-block;
	color: #ffffff;
	vertical-align: middle;
	margin:0;
}

.footer-distributed .footer-center p span{
	display:block;
	font-weight: normal;
	font-size:14px;
	line-height:2;
}

.footer-distributed .footer-center p a{
	color:  #5383d3;
	text-decoration: none;;
}


/* Footer Right */

.footer-distributed .footer-right{
	width: 28%;
}


.footer-distributed .footer-company-about{
	line-height: 20px;
	color:  #92999f;
	font-size: 13px;
	font-weight: normal;
	margin: 0;
}

.footer-distributed .footer-company-about span{
	display: block;
	color:  #ffffff;
	font-size: 14px;
	font-weight: bold;
	margin-bottom: 20px;
}

.footer-distributed .footer-icons{
	margin-top: 25px;
	margin: 30px;
}

.footer-distributed .footer-icons a{
	display: inline-block;
	width: 35px;
	height: 35px;
	cursor: pointer;
	background-color:  #33383b;
	border-radius: 2px;

	font-size: 20px;
	color: #ffffff;
	text-align: center;
	line-height: 35px;

	margin-right: 3px;
	margin-bottom: 5px;
}

/* If you don't want the footer to be responsive, remove these media queries */

@media (max-width: 880px) {

	.footer-distributed{
		font: bold 14px sans-serif;
	}

	.footer-distributed .footer-left,
	.footer-distributed .footer-center,
	.footer-distributed .footer-right{
		display: block;
		width: 100%;
		margin-bottom: 40px;
		text-align: center;
	}

	.footer-distributed .footer-center i{
		margin-left: 0;
	}

}
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 250px;
  padding: 50px;
  float: right;
  margin: 1%;
  text-align: center;
  margin-top: 5%;
  font-family: arial;
}

.price {
  color: grey;
  font-size: 22px;
}

.btn{
  border: none;
  outline: 0;
  margin-top: 15px;
  padding: 12px;
  color: white;
  background-color: Green;
  text-align: center;
  cursor: pointer;
  width: 90%;
  font-size: 18px;
}

.card button:hover {
  opacity: 0.7;
}
.main h3 {
	margin-left: 100px;
	color: #333;
	background: #8E9095;
	padding: 10px;
	margin-right: 50px;
	text-align: center;
}
.container {
  border-radius: 5px;
  padding: 10px;
}

/* Create two columns that float next to eachother */
.column {
  float: left;
  width: 50%;
  margin-top: 6px;
  padding: 20px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
body {
    display: flex;
    min-height: 100vh;
    flex-direction: column;
  }

  main {
    flex: 1 0 auto;
  }
  
  .form-inline {
display: inline-block;
margin-left: 20%;
}

/* Add some margins for each label */
.form-inline label {
  margin: 5px 10px 5px 0;
}

/* Style the input fields */
.form-inline input {
  vertical-align: middle;
  margin: 5px 10px 5px 0;
  padding: 5px;
  background-color: #fff;
  border: 1px solid #ddd;
}

/* Style the submit button */
.form-inline button {
  padding: 10px 20px;
  background-color: dodgerblue;
  border: 1px solid #ddd;
  color: white;
}

.form-inline button:hover {
  background-color: royalblue;
}

/* Add responsiveness - display the form controls vertically instead of horizontally on screens that are less than 800px wide */
@media (max-width: 800px) {
  .form-inline input {
    margin: 10px 0;
  }

  .form-inline {
    flex-direction: column;
    align-items: stretch;
  }
}
.color {
	 background: #eee;
}

form {
  border: 3px solid #f1f1f1;
}

/* Full-width inputs */
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

/* Set a style for all buttons */
button {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

/* Add a hover effect for buttons */
button:hover {
  opacity: 0.8;
}

/* Extra style for the cancel button (red) */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

/* Center the avatar image inside this container */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

/* Avatar image */
img.avatar {
  width: 40%;
  border-radius: 50%;
}

/* Add padding to containers */
.container {
  padding: 20px;
}

/* The "Forgot password" text */
span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
    display: block;
    float: none;
  }
  .cancelbtn {
    width: 100%;
  }
}
</style>
</head>
<body>

<div id= navbar >
  <img style="height: 40%px;width:15%;margin-left:30px;" src=logo.png alt="Logo"  >
  <div id= navbar-right >
    <a href= index.php class="fa fa-home" style="font-size:30px" alt="Home" abbr title="Home"></a>
    <a href= Shop.php class="fa fa-shopping-cart" style="font-size:24px" abbr title="Shop"></a>
    <a href= Contact.php abbr title="Contact" class="fa fa-address-book" style="font-size:22px" aria-hidden="true"></a>
    <a href= About.php abbr title="About" class="fa fa-question-circle" style="font-size:25px" aria-hidden="true"></a>
 </div>
</div>
<br>
<br>
<br>

<br>
<br>
</div>
<div class="header">
  <center><img src="bg1.jpg" style="background-size:cover;background-repeat: no-repeat;width: 98%;height:60%;"></center>
</div>

<?php
$i1 = "Hammer";
$i2 = "Hammer";
$i3 = "Hammer";
$i4 = "Hammer";
$i5 = "Hammer";
$i6 = "Hammer";
$i7 = "Hammer";
$i8 = "Hammer";


$Pprice1 = "300";
$Pprice2 = "300";
$Pprice3 = "300";
$Pprice4 = "300";
$Pprice5 = "300";
$Pprice6 = "300";
$Pprice7 = "300";
$Pprice8 = "300";


?>

<div class="row">
  <div class="side">

  
 <center> <div class="imgcontainer">
    <img src="exe.png" alt="Avatar" style="width: 100px;height: 100px;margin-right: 20px;" class="avatar">
  </div>
</center>


<script>
function validate() {
  var user = document.forms["loginform"]["uname"].value;
  var pass = document.forms["loginform"]["psw"].value;
  if (user !="Admin" && pass !="admin") {
    alert(" Incorrect Username or Password ! ");
 return false;
  }
}
</script>
<center><h3> Admin Panel </h3></center>
  <div class="container">
	<form action="Admin.php" onsubmit="return validate()" name="loginform">
	<br>
    <label for="uname"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="uname" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>

    <button type="submit" name="submit" onclick="myFunction()">Login</button>
    <label>
 
    </label>
  </div>
  <div class="container" style="background-color:#f1f1f1">
  </div>
</form>
<hr>
  </div>
  <div class="main">
     <div class="col-lg-4 col-md-4 col-sm-4 col-4">
	 <h3> OTHERS </h3>
<div class="card">
  <a href="Details.html"><img src="o1.png" alt="Hammer" style="width:100%;"></a>
  <h1><?php echo $i1; ?></h1>
  <p class="price"><?php echo $Pprice1; ?></p>
   <input type="text" style="text-align:center;width:50%;" name="q1" class="form-control" value="1">
  <input class="btn" type="submit" name="insert" value="Add to Cart">
</div>
<div class="card">
  <a href="Details.html"><img src="o6.png" alt="Hammer" style="width:100%;"></a>
  <h1><?php echo $i1; ?></h1>
  <p class="price"><?php echo $Pprice1; ?></p>
   <input type="text" style="text-align:center;width:40%;" name="q1" class="form-control" value="1">
  <input class="btn" type="submit" name="insert" value="Add to Cart">
</div>
<div class="card">
  <a href="Details.html"><img src="i3.png" alt="Hammer" style="width:100%;"></a>
  <h1><?php echo $i1; ?></h1>
  <p class="price"><?php echo $Pprice1; ?></p>
   <input type="text" style="text-align:center;width:40%;" name="q1" class="form-control" value="1">
  <input class="btn" type="submit" name="insert" value="Add to Cart">
</div>
<div class="card">
  <a href="Details.html"><img src="i4.png" alt="Hammer" style="width:100%;"></a>
  <h1><?php echo $i1; ?></h1>
  <p class="price"><?php echo $Pprice1; ?></p>
   <input type="text" style="text-align:center;width:40%;" name="q1" class="form-control" value="1">
  <input class="btn" type="submit" name="insert" value="Add to Cart">
</div>
<div class="card">
  <a href="Details.html"><img src="i25.png" alt="Hammer" style="width:100%;"></a>
  <h1><?php echo $i1; ?></h1>
  <p class="price"><?php echo $Pprice1; ?></p>
   <input type="text" style="text-align:center;width:40%;" name="q1" class="form-control" value="1">
  <input class="btn" type="submit" name="insert" value="Add to Cart">
</div>
<div class="card">
  <a href="Details.html"><img src="i46.png" alt="Hammer" style="width:100%;"></a>
  <h1><?php echo $i1; ?></h1>
  <p class="price"><?php echo $Pprice1; ?></p>
   <input type="text" style="text-align:center;width:40%;" name="q1" class="form-control" value="1">
  <input class="btn" type="submit" name="insert" value="Add to Cart">
</div>
</div>
  </div>
</div>

		
<footer class= footer-distributed >

			<div class= footer-left >

				<img style="height:15%;width:70%;margin-left:0px;margin-top:5%;" src=logo.png >


				<p class= footer-company-name >Execute &copy; 2019</p>
			</div>

			<div class= footer-right >

				<p class= footer-company-about >
					<span>About  Company </span>Reydie K Hardware or Reymond Edie Kabigting Hardware, The company is managed by the family of Kabigting, 
and the President of the hardware which is the father of the family Kabigting, Mr......
</span>
				</p>

				<div class= footer-icons >
				<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
  <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
  <a href="#" class="google"><i class="fa fa-google"></i></a>
  <a href="#" class="youtube"><i class="fa fa-youtube"></i></a>

				</div>

			</div>

			<div STYLE="float: right;" class= footer-right >

			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4436.643852957726!2d121.04018957460768!3d14.777228289785706!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397afd00f8846bf%3A0xb06ac44183dd36a5!2sBagong%20Silang%2C%20Caloocan%2C%20Metro%20Manila!5e1!3m2!1sen!2sph!4v1570320735217!5m2!1sen!2sph" width="600" height="450" frameborder="0" style="border:0;height: 200px;margin-right: 40px;width:110%;" allowfullscreen=""></iframe>
				

			</div>

		</footer>
            